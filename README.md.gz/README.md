# signature
Searching Signature in Files

## Como usar

```
git clone https://github.com/heukirne/signature
cd signature
gcc antivirus.c -o antivirus
./antivirus signature < file_list.txt
```
